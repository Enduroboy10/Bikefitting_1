import cv2
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import os
import ohnegui as og

# Create the main application window
root = tk.Tk()
root.title("Bikefitting App")

# Set initial size and position of the window
root.geometry("1200x800")  # Width x Height
root.minsize(800, 600)    # Minimum window size
root.maxsize(1920, 1080)  # Maximum window size

# Initialize global variables
video_label = None
cap = None  # VideoCapture object
is_playing = False  # Video play state
window_width = 1200
window_height = 800
file_path = None  # Initialize file_path globally

def toggle_fullscreen(event=None):
    root.attributes("-fullscreen", not root.attributes("-fullscreen"))

def close_app(event=None):
    global cap
    if cap:
        cap.release()
    root.destroy()

def import_video():
    global cap, file_path, is_playing
    file_path = filedialog.askopenfilename(
        title="Select a Video File",
        filetypes=[("Video Files", "*.mp4 *.avi *.mov *.mkv"), ("All Files", "*.*")]
    )
    if file_path:
        label.config(text=f"Playing Video: {file_path}")
        cap = cv2.VideoCapture(file_path)
        is_playing = True
        play_video()
    else:
        label.config(text="No video selected.")

def get_process():
    global cap, video_label, is_playing
    if file_path:
        if cap:
            is_playing = False
            cap.release()
            cap = None
        if video_label:
            video_label.destroy()
            video_label = None

        frames = og.extract_fr(file_path)
        resp = og.get_interf(frames[0])
        frame, angle = og.show_inference_result_with_keypoints(resp, frames[0])

        if angle > 30:
            angle_label.config(text="Decrease saddle height", fg="red")
        elif 25 <= angle <= 30:
            angle_label.config(text="Saddle height is in range", fg="green")
        else:
            angle_label.config(text="Raise saddle height", fg="blue")

        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_height, frame_width, _ = frame.shape
        scale = min(window_width / frame_width, window_height / frame_height)
        new_width, new_height = int(frame_width * scale), int(frame_height * scale)
        frame = cv2.resize(frame, (new_width, new_height))
        img = ImageTk.PhotoImage(Image.fromarray(frame))
        
        video_label = tk.Label(root, image=img)
        video_label.image = img
        video_label.pack(expand=True)
        label.config(text="Processed frame displayed.")
    else:
        label.config(text="No video selected for processing!")

def play_video():
    global cap, video_label, is_playing, window_width, window_height
    if not cap or not is_playing:
        return

    ret, frame = cap.read()
    if ret:
        frame_height, frame_width, _ = frame.shape
        scale = min(window_width / frame_width, window_height / frame_height)
        new_width, new_height = int(frame_width * scale), int(frame_height * scale)
        frame = cv2.resize(frame, (new_width, new_height))
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = ImageTk.PhotoImage(Image.fromarray(frame))

        if not video_label:
            video_label = tk.Label(root)
            video_label.pack(expand=True)
        video_label.config(image=img)
        video_label.image = img
        root.after(30, play_video)
    else:
        cap.release()
        cap = None
        video_label.destroy()
        video_label = None
        is_playing = False
        label.config(text="Video playback finished.")

label = tk.Label(root, text="", font=("Arial", 16))
label.pack(pady=10)

import_button = tk.Button(root, text="Import Video", font=("Arial", 14), command=import_video)
import_button.place(x=10, y=10)

keypoints_button = tk.Button(root, text="Get key points and knee angle", font=("Arial", 14), command=get_process)
keypoints_button.place(x=10, y=60)

angle_label = tk.Label(root, text="", font=("Arial", 16))
angle_label.pack(pady=10)

def restart_process():
    global cap, video_label, is_playing, file_path
    if cap:
        is_playing = False
        cap.release()
        cap = None
    if video_label:
        video_label.destroy()
        video_label = None
    label.config(text="Application reset. Ready to start again.")
    angle_label.config(text="", fg="black")
    file_path = None
    placeholder = tk.Label(root, text="Frame reset. No video or image loaded.", font=("Arial", 14))
    placeholder.pack(expand=True)
    placeholder.place(x=window_width // 2 - 150, y=window_height // 2 - 20)

restart_button = tk.Button(root, text="Restart Process", font=("Arial", 14), command=restart_process)
restart_button.place(x=10, y=110)

root.bind("<F11>", toggle_fullscreen)
root.bind("<Escape>", close_app)
root.mainloop()
